<?php
$host       =   "localhost";
$username   =   "root";
$pass       =   "";
$database   =   "dummypajak";
$koneksi    =   mysqli_connect($host, $username, $pass, $database);
?>